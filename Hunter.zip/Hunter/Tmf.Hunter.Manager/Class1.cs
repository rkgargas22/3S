﻿namespace Tmf.Hunter.Manager
{
    public class Class1
    {

    }
}