﻿namespace Tmf.Hunter.Core
{
    public class Class1
    {

    }
}